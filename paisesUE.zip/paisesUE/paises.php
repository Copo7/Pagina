<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cristian Fernandez Cornejo PaisesUE</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        table {
            width: 80%;
            border-collapse: collapse;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            border-radius: 8px;
            overflow: hidden;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
        }
        th {
            background-color: #004080;
            color: #ffffff;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #e0e7ff;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th>Bandera</th>
            <th>Nombre</th>
            <th>Capital</th>
            <th>Población</th>
            <th>Código ISO</th>
        </tr>
        <?php include "codigo.php" ?>
        <?php foreach ($paisesUE as $pais): ?>
            <tr>
                <td><img src="https://flagcdn.com/16x12/<?= strtolower($pais["codigo_iso"]) ?>.png" alt="Bandera de <?= htmlspecialchars($pais["nombre"]) ?>"></td>
                <td><?= htmlspecialchars($pais["nombre"]) ?></td>
                <td><?= htmlspecialchars($pais["capital"]) ?></td>
                <td><?= number_format($pais["poblacion"]) ?></td>
                <td><?= htmlspecialchars($pais["codigo_iso"]) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
